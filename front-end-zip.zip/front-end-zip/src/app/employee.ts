export class Employee {
    id!: number;
    emp_name!: string;
    date_of_joining!: Date;
    gender!: string;
    age!: number;
    designation!: string;
    email!: string;
    password!: string;

}
package com.mphasis.employee_payroll.service;

import com.mphasis.employee_payroll.model.ChangePassword;

public interface ChangePasswordService {

	ChangePassword changePassword(ChangePassword changePassword, long id);

}